import java.sql.ResultSet;


public class StaffRowMapper implements RowMapper<String>{

	public class getPwd(ResultSet rs, int rownum)
	{
		return rs.getString(1);
	}
}
