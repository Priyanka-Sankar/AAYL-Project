package com.project.student;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.project.exam.ExamDao;
import com.project.result.ResultBean;
import com.project.result.ResultDao;

public class StudentApp
{
	public static void main(String[] args) throws SQLException
	{
		Scanner get = new Scanner(System.in);
		StudentDao studDao = new StudentDao();
		ExamDao examDao = new ExamDao();
		ResultDao resultDao = new ResultDao();
		String eid;
		System.out.println("Enter your student id:");
		String id = get.nextLine();
		System.out.println("Enter your password:");
		String pwd = get.nextLine();
		if(studDao.login(id,pwd))
		{
			int ch;
			do{
				System.out.println("\n1. Attend Exam\n2. Results\n3. Logout\nEnter your choice\n");
				ch=get.nextInt();
				
				switch(ch)
				{
				case 1 : List<String> exam = examDao.printExam();
						 Iterator<String> itr = exam.iterator();
						 System.out.println("Exam id \t Exam Name");
						 while(itr.hasNext())
						 {
							 System.out.println(itr.next());
						 }
						 get.nextLine();
						 System.out.println("Enter the exam id which you want to attend exam");
						 eid = get.nextLine();
						 examDao.attendExam(eid,id);
						 System.out.println("Hai");
						 break;
				case 2 : get.nextLine();
						 System.out.println("Enter the exam name :");
						 String ename = get.nextLine();
						 eid = examDao.fetchExamId(ename);
						 if(eid != null){
						 ResultBean resultBean = resultDao.viewResult(id, eid);
						 System.out.println("--------Your Results For Exam - "+ename+"-----------");
						 System.out.println("Total number of correct answers : "+resultBean.getCorrectAns());
						 System.out.println("Total number of wrong answers : "+resultBean.getWrongAns());
						 System.out.println("YOUR SCORE : "+resultBean.getScore());
						 }
						 else
							 System.out.println("No such exam is avaliable");
						 break;
				default :System.out.println("---------------------You have successfully logout---------------------------------");
						 System.exit(0);
				}
			}while(ch<=2);
		}
		else
			System.out.println("Login Failed.......");
	}
}