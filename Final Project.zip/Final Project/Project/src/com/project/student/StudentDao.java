package com.project.student;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.connection.ConnectionManager;
import com.project.exam.ExamDao;

public class StudentDao{
	
	ExamDao examDao = new ExamDao();
	public Boolean addStudent(StudentBean sb) throws SQLException {
		String sid=sb.getStudentId();
		String sname=sb.getStudentName();
		String dname=sb.getDeptName();
		String staffId = sb.getStaffId();
		String pwd=sb.getPwd();
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="INSERT INTO STUDENT VALUES('"+sid+"','"+staffId+"','"+sname+"','"+dname+"','"+pwd+"')";
			//System.out.println(sql);
			if(st.executeUpdate(sql) > 0)
				return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
			
		}
		return false;
	}


	public Boolean deleteStudent(String sid) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="DELETE FROM STUDENT WHERE id='"+sid+"'";
			if(st.executeUpdate(sql)>0)
				return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
			
		}
		return false;
	}


	public List getDetails() throws SQLException
	{
			
			//step 3: create statement object 
			Connection conn = ConnectionManager.getConnection();
			Statement stmt = null;
			List<StudentBean> holdingsList = null;
			try {
				 stmt = conn.createStatement();
			 
				
				ResultSet resultset = stmt.executeQuery("SELECT * FROM STUDENT");			
				 holdingsList = new ArrayList<StudentBean>();
				while(resultset.next()) {
					StudentBean studentBean = new StudentBean();
					studentBean.setStudentId(resultset.getString(1));
					studentBean.setStudentName(resultset.getString(2));
					studentBean.setDeptName(resultset.getString(3));
					studentBean.setPwd(resultset.getString(4));
					holdingsList.add(studentBean);
							
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
			
			return holdingsList;
	}
	public Boolean login(String loginId,String pwd) throws SQLException {
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try
		{ 
			stmt = conn.createStatement();
			String sql = "SELECT pwd FROM STUDENT WHERE id ='"+loginId+"'";
			ResultSet resultset = stmt.executeQuery(sql);
			System.out.println(sql);
			while(resultset.next())
			{
				if(pwd.equals(resultset.getString(1)))
					return true;
			}
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return false;
	}


	public String getStudName(String studId) throws SQLException {
		
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try
		{ 
			stmt = conn.createStatement();		 
			ResultSet resultset = stmt.executeQuery("SELECT sname FROM STUDENT WHERE id = '"+studId+"'");
			if(resultset.next())
				return resultset.getString(1);
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return null;
	}


	public Boolean updateLogin(String id, String pwd) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="UPDATE STUDENT SET pwd = '"+pwd+"' WHERE id = '"+id+"'";
			System.out.println(sql);
			if(st.executeUpdate(sql)>0)
				return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
			
		}
		return false;
	}


	

}
