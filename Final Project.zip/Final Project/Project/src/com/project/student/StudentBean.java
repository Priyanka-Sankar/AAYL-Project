package com.project.student;

public class StudentBean {
	private String studentId;
	private String staffId;
	private String studentName;
	private String deptName;
	private String pwd;
	
	public StudentBean(String studentId, String staffId, String studentName, String deptName, String pwd) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.deptName = deptName;
		this.pwd = pwd;
		this.staffId = staffId;
	}
	
	

	public StudentBean() {
		// TODO Auto-generated constructor stub
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	
	
}
