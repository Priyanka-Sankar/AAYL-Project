package com.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.student.StudentDao;

/**
 * Servlet implementation class DelStudent
 */
@WebServlet("/DelStudent")
public class DelStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DelStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(false);  
        if(session!=null)  
		{
		String str = request.getParameter("idName");
		String[] split = str.split("-");
		StudentDao studDao = new StudentDao();
		try {
			if(studDao.deleteStudent(split[0]))
			{
				RequestDispatcher rd = request.getRequestDispatcher("delStudent.jsp");
				rd.include(request, response);
				out.print("<div style='text-align:center;color:red'><b><br><br><br>Deleted Successfully</b></div>");
			}
			else
			{
				RequestDispatcher rd = request.getRequestDispatcher("delStudent.jsp");
				rd.include(request, response);
				out.print("<div style='text-align:center;color:red'><b><br><br><br>Error in deletion</b></div>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			out.print(e.getMessage());
		}
		}
		 else{
        	 out.print("Please login first");  
             request.getRequestDispatcher("index.jsp").include(request, response);  
        }
	}

}
