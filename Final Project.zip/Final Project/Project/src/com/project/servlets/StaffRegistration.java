package com.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.project.staff.StaffBean;
import com.project.staff.StaffDao;

/**
 * Servlet implementation class StaffRegistration
 */
@WebServlet("/StaffRegistration")
public class StaffRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig config;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StaffRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void init(ServletConfig config)
    {
    	this.config = config;
    	System.out.println("StaffRegistration got instantiated");
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		System.out.println("called");
		response.setContentType("text/html");
		
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\XBBNC93\\workspace2\\Project\\WebContent\\WEB-INF\\spring-servlet.xml"));
		DataSource obj = (DataSource) factory.getBean("ds");    
		StaffDao staffDao = new StaffDao(obj);
		
		String staffId = request.getParameter("stid");
		String staffName = request.getParameter("stname");
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		
		try {
			if(staffDao.signUp(new StaffBean(staffId, staffName, pwd, email))>0)
			{
				RequestDispatcher rd = request.getRequestDispatcher("staffSignup.jsp");
				rd.include(request, response);
				out.print("<div style='text-align:center;color:green;'><h3><br><br>  Registered Successfully</h3></div>");
			}
			else
			{
				RequestDispatcher rd = request.getRequestDispatcher("staffSignup.jsp");
				rd.include(request, response);
				out.print("<div style='text-align:center;color:red;'><h3><br><br>  Can't Register</h3></div>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
