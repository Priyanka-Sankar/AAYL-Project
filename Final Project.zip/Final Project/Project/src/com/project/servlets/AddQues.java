package com.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.question.QuestionBean;
import com.project.question.QuestionDao;

/**
 * Servlet implementation class AddQues
 */
@WebServlet("/AddQues")
public class AddQues extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig config;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	public void init(ServletConfig config)
	{
		this.config = config;
		System.out.println("Insideeeeeeeeeeeeeeee");
	}
    public AddQues() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(false);
		QuestionDao quesDao = new QuestionDao();
        if(session!=null)
        {  
		String eid = request.getParameter("eid");
		int count = Integer.parseInt(request.getParameter("count"));
		int c=0, flag=0;
		int qid=0;
		try {
			qid = quesDao.getCount(eid);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i=0;i<count;i++)
		{
			String ques = request.getParameter("name"+i);
			String optA = request.getParameter("optA"+i);
			String optB = request.getParameter("optB"+i);
			String optC = request.getParameter("optC"+i);
			String optD = request.getParameter("optD"+i);
			
			if(ques != null)
			{
				qid++;
				int ans = Integer.parseInt(request.getParameter("ques"+i));
				try {
					if(!quesDao.addQuestion(eid, new QuestionBean(qid, ques, optA, optB, optC, optD, ans)))
					{
						flag=1;
						RequestDispatcher rd = request.getRequestDispatcher("addQuesViaExam.jsp");
						rd.include(request, response);
						out.print("<div style='text-align:center;color:red'><b><br><br><br>Error in insertion</b></div>");
						break;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		if(flag==0)
		{
			RequestDispatcher rd = request.getRequestDispatcher("addExam.jsp");
			rd.include(request, response);
			out.print("<html><body><div style='text-align:center;color:green'><b><br><br><br>Inserted Successfully</b></div></body.</html>");
		}
        }
        else{
          	 out.print("Please login first");  
               request.getRequestDispatcher("index.jsp").forward(request, response);  
          }
	}

}
