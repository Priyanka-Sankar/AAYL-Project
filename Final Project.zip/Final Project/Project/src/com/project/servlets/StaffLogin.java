package com.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.project.staff.StaffDao;

/**
 * Servlet implementation 
 */
//@WebServlet("/RecordUserDetails")
public class StaffLogin extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	private ServletConfig config;

    /**
     * Default constructor. 
     */
    public StaffLogin() 
    {
        // TODO Auto-generated constructor stub
    }
    public void init(ServletConfig config)
    {
    	this.config = config;
    	System.out.println("StaffLogin instantiated");
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
        response.setContentType("text/html");
		String loginId = request.getParameter("stid");
		String pwd = request.getParameter("pwd");
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\XBBNC93\\workspace2\\Project\\WebContent\\WEB-INF\\spring-servlet.xml"));
		DataSource obj = (DataSource) factory.getBean("ds");    
		StaffDao staffDao = new StaffDao(obj);
		try {
			if(staffDao.login(loginId, pwd))
			{
				HttpSession session=request.getSession();  
		        session.setAttribute("name",loginId);  
				 RequestDispatcher dispatcher = request.getRequestDispatcher("addStudent.jsp");
	             dispatcher.include(request, response);
			}
			else
			{
			
	             RequestDispatcher dispatcher = request.getRequestDispatcher("staffLogin.jsp");
	             dispatcher.include(request, response);
	             out.print("<div style='text-align:center;'><b>Login Failed</b></div>");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	}

		


