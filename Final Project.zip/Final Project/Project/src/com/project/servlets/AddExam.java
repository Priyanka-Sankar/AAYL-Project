package com.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.exam.ExamBean;
import com.project.exam.ExamDao;

/**
 * Servlet implementation class AddExam
 */
@WebServlet("/AddExam")
public class AddExam extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddExam() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        System.out.print("Inside");
		String examId = request.getParameter("eid");
		String ename = request.getParameter("ename");
		int posMark = Integer.parseInt(request.getParameter("posMark"));
		int negMark = Integer.parseInt(request.getParameter("negMark"));
		int duration = Integer.parseInt(request.getParameter("dur"));
		ExamDao examDao = new ExamDao();
		 HttpSession session=request.getSession(false);  
	        if(session!=null){  
		try {
			if(examDao.addExam(new ExamBean(examId, ename, posMark, negMark, duration)))
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("addQuesViaExam.jsp");
	             dispatcher.forward(request, response);
				
			}
			else
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("addExam.jsp");
	             dispatcher.include(request, response);
			    out.print("<div style='text-align:center;color:red'><b><br><br><br>Error in insertion</b></div>");				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
	        else
	        {
	        	 out.print("<div style='text-align:center;color:red'><b><br><br><br>Login First</b></div>");  
	             request.getRequestDispatcher("index.jsp").include(request, response);  
	        }
	}

}
