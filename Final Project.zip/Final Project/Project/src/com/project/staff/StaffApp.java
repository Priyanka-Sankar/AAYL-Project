package com.project.staff;

import java.sql.SQLException;
import java.util.Scanner;

import com.project.exam.ExamBean;
import com.project.exam.ExamDao;
import com.project.question.QuestionBean;
import com.project.question.QuestionDao;
import com.project.result.ResultDao;
import com.project.student.StudentBean;
import com.project.student.StudentDao;

public class StaffApp {
	
	static int count;
	public static void main(String[] args) throws SQLException
	{
		Scanner get = new Scanner(System.in);
		StaffDao staffDao = new StaffDao();
		StudentDao studentDao = new StudentDao();
		ExamDao examDao = new ExamDao();
		QuestionDao quesDao = new QuestionDao();
		ResultDao resultDao = new ResultDao();
		int choice;
		do{ 
			System.out.println("1. Login\n2. Signup\nEnter your choice:");
			choice = get.nextInt();
			switch(choice)
			{
			case 1: 	get.nextLine();
						System.out.println("Enter your login Id:");
						String loginId = get.nextLine();
						System.out.println("Enter your password:");
						String password = get.nextLine();
						if(staffDao.login(loginId, password))
						{
							int ch;
							do{
								System.out.println("\n1. Managing Student Details\n2. Managing Exam Details\n3. View Results\n4. LogoutEnter your choice:");
								ch = get.nextInt();
								switch(ch)
								{
								case 1 :int ch1; 
										do{
											System.out.println("1. Add Student\n2. Delete Student\nEnter your choice:");
											ch1 = get.nextInt();
											switch(ch1)
											{
											case 1 : StudentBean studentBean = new StudentBean();
													 get.nextLine();
													 System.out.println("Enter the student id : ");
													 studentBean.setStudentId(get.nextLine());
													 System.out.println("Enter the student name :");
													 studentBean.setStudentName(get.nextLine());
													 System.out.println("Enter the student department :");
													 studentBean.setDeptName(get.nextLine());
													 System.out.println("Enter the password :");
													 studentBean.setPwd(get.nextLine());
													 studentDao.addStudent(studentBean);
													 System.out.println("Inserted successfully....");
													 break;
											case 2 : System.out.println("Enter the student id to be deleted:");
													 int id = get.nextInt();
													 studentDao.deleteStudent(""+id);
													 System.out.println("Deleted Successfully");
													 break;
											default : break;
											}
										}while(ch1<=2);
										 break;
								case 2 : int ch2;
										 do
										 {
											 System.out.println("1. Add Exam\n2. Delete Exam\n3. Add Questions\n4. Delete Questions\nEnter your choice");
											 ch2 = get.nextInt();
											 switch(ch2)
											 {
											 case 1	 :	get.nextLine();
												 		System.out.println("Enter exam id :");
											 		 	String examId = get.nextLine();
											 		 	System.out.println("Enter exam name :");
											 		 	String examName = get.nextLine();
											 		 	System.out.println("Enter +ve mark :");
											 		 	int posMark = get.nextInt();
											 		 	System.out.println("Enter -ve mark :");
											 		 	int negMark = get.nextInt();
											 		 	ExamBean examBean = new ExamBean(examId, examName, posMark, negMark, 0);
											 		 	examDao.addExam(examBean);
											 		 	System.out.println("Now you can add questions.....!!!");
											 		 	break;
											 case 2	:	get.nextLine();
												 		System.out.println("Enter exam name :");
											 			examName = get.nextLine();
											 			examId = examDao.fetchExamId(examName);
											 			examDao.deleteExam(examId);
											 			break;
											 case 3	:	get.nextLine();
												 		System.out.println("Enter the exam name in which you want to add questions:");
											 			examName = get.nextLine();
											 			examId = examDao.fetchExamId(examName);
											 			System.out.println("Enter the number of questions :");
											 			int n = get.nextInt();
											 			get.nextLine();
											 			int count = quesDao.getCount(examId);
											 			for(int i=0;i<n;i++)
											 			{
											 				count++;
											 				System.out.println("------------Question No "+(count)+"------------");
											 				System.out.println("Enter the question:");
											 				String desc = get.nextLine();
											 				System.out.println("Enter the option 1:");
											 				String optA = get.nextLine();
											 				System.out.println("Enter the option 2:");
											 				String optB = get.nextLine();
											 				System.out.println("Enter the option 3:");
											 				String optC = get.nextLine();
											 				System.out.println("Enter the option 4:");
											 				String optD = get.nextLine();
											 				System.out.println("Enter the correct option no :");
											 				int correctAns = get.nextInt();
											 				QuestionBean qBean = new QuestionBean(count,desc, optA, optB, optC, optD, correctAns);
											 				quesDao.addQuestion(examId, qBean);
											 			}
											 			break;
											 case 4	:	get.nextLine();
												 		System.out.println("Enter the exam name in which you want to delete questions");
											 			examName = get.nextLine();
											 			examId = examDao.fetchExamId(examName);
											 			System.out.println("Enter the question id :");
											 			int quesId = get.nextInt();
											 			quesDao.deleteQuestion(examId, quesId);
											 default : break;
											 }
										 }while(ch2<=4);
											
										 break;
								case 3	:	int ch3;
											do{
												System.out.println("\n1. View by exam Name\n2. View by student Name\nEnter your choice");
												ch3 = get.nextInt();
												switch(ch3)
												{
												case 1	:	get.nextLine();
															System.out.println("Enter exam name :");
															String examName = get.nextLine();
															String examId = examDao.fetchExamId(examName);
															resultDao.viewByExam(examId);
															break;
												case 2	:	get.nextLine();
															System.out.println("�nter student name :");
															String sname =  get.nextLine();
															//String studId = studentDao.getStudName(sname);
															resultDao.viewByStudent(sname);
												}
											}while(ch3<=2);
								case 4	:	System.out.println("You have successfully logged out.....!!!!");
											System.exit(0);
								}
							  }while(ch<=4);
							
					    }
					    else
						  System.out.println("Login Failed.......");
					    break;
					    
			case 2 :	get.nextLine();
						System.out.println("Enter your staff id:");
						String staffId = get.nextLine();
						System.out.println("Enter your name:");
						String staffName = get.nextLine();
						System.out.println("Enter your password:");
						String pwd = get.nextLine();
						System.out.println("Enter confirm password:");
						String cpwd = get.nextLine();
						if(pwd.equals(cpwd))
						{
							StaffBean staffBean = new StaffBean(staffId, staffName,"hello@gmail.com", pwd);
							staffDao.signUp(staffBean);
							System.out.println("You have successfully completed REGISTRATION... Now you can LOGIN..");
						}
						else
							System.out.println("Password and Confirm password should be equal..");
						break;
			
			}
		}while(choice <= 2);
	}
}
