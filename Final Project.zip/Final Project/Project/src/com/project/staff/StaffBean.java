package com.project.staff;

public class StaffBean {
	private String staffId;
	private String staffName;
	private String password;
	private String emailId;
	public StaffBean(String staffId, String staffName, String password, String emailId) {
		super();
		this.staffId = staffId;
		this.staffName = staffName;
		this.password = password;
		this.emailId = emailId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
