package com.project.staff;

import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.project.mapper.StaffRowMapper;

public class StaffDao extends JdbcDaoSupport{

	@Autowired
	public StaffDao(DataSource datasource)
	{
		System.out.println("hfgdsagkj   called");
		setDataSource(datasource);
	}
	public StaffDao(){}
	
	@SuppressWarnings("unchecked")
	public Boolean login(String loginId, String pwd) throws SQLException {
			
			System.out.println(loginId+" "+pwd);		 
			List<String> password = getJdbcTemplate().query("SELECT pwd FROM STAFF WHERE stid ='"+loginId+"'", 
					new Object[]{}, new StaffRowMapper());
			System.out.println(password.get(0));
			if(pwd.equals(password.get(0)))
					return true;
			return false;
	}

	public String getEmail(String loginId) throws SQLException {
		
		 
		List<String> email = getJdbcTemplate().query("SELECT email FROM STUDENT s,STAFF s1 where s.stid = s1.stid and s.id='"+loginId+"'", 
				new Object[]{}, new StaffRowMapper());
		return email.get(0);
}
	public int signUp(StaffBean staffBean) throws SQLException {
		
		String stid = staffBean.getStaffId();
		String sname = staffBean.getStaffName();
		String pwd = staffBean.getPassword();
		String email = staffBean.getEmailId();
		
		int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR };
		Object param[] = {stid, sname, email, pwd};
		
		int numRows = getJdbcTemplate().update(
				"insert into STAFF values(?,?,?,?)", param, types);
		
		return (numRows == 1 ? 1 : 0);
	}
}
