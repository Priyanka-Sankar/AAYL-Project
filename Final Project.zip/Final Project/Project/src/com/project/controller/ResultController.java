package com.project.controller;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.exam.ExamDao;
import com.project.result.ResultBean;
import com.project.result.ResultDao;
import com.project.result.ResultDaoImpl;
import com.project.student.StudentBean;
import com.project.student.StudentDao;


@RestController
@RequestMapping(value = "/results")

public class ResultController {

	@Autowired
	ResultDaoImpl resDaoi;
	  StudentDao studDao = new StudentDao();
	ResultDao resDao = new ResultDao();
	List<ResultBean> sb = new ArrayList<ResultBean>();
	  @RequestMapping(value = "/all" , method = RequestMethod.PUT )
	  public String updateLogin(@RequestBody StudentBean sb) throws SQLException {
	
		  String id = sb.getStudentId();
		  String pwd = sb.getPwd();
		  System.out.println(id+"    "+pwd);
		  if(studDao.updateLogin(id, pwd))
			  return "Updated";
		  else
			  return "Error in insertion";
		
      }
	  @RequestMapping(value = "/all" , method = RequestMethod.POST )
	  public String addStudent(@RequestBody StudentBean sb) throws SQLException {
			
		  	if(studDao.addStudent(sb))
		  		return "inserted";
		  	return "Error in Insertion";
		}
	  
	  @RequestMapping(value="all/{studId}", method=RequestMethod.GET)
	  public List<ResultBean> getStudDetails(@PathVariable("studId") String studId) throws SQLException{
		  System.out.println("haiiiiiiiiiiiiiiiii");
		  sb = resDao.viewByStud(studId);
		  System.out.println("size "+sb.size());
		  return sb;
	  }
	  @RequestMapping(value="exam/{studId}", method=RequestMethod.GET)
	  public List<String> getEname(@PathVariable("studId") String studId) throws SQLException{
		  ExamDao examDao = new ExamDao();
		  sb = resDao.viewByStud(studId);
		  List<String> str = new ArrayList<String>();
		  for(int i=0;i<sb.size();i++){
			  str.add(examDao.fetchExamDet(sb.get(i).getEid()).getExamName());
			  System.out.println("str "+str.get(i));
		  }
		 //String jstr=new Gson().toJson(str);
		  return str;
	  }
	  @RequestMapping(value="all/{studId}", method=RequestMethod.DELETE)
	  public Boolean deleteStudent(@PathVariable("studId") String studId) throws SQLException
	  {
		  if(studDao.deleteStudent(studId))
			  return true;
		  return false;
	  }

}
