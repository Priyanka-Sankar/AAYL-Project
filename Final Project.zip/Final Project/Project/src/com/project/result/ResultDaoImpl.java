package com.project.result;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.project.exam.ExamDao;
import com.project.mapper.StudRowMapper;
@Component
public class ResultDaoImpl extends JdbcDaoSupport {
	
	@Autowired
	public ResultDaoImpl(DataSource datasource)
	{
		System.out.println("hfgdsagkj   called");
		setDataSource(datasource);
	}
	
public List<ResultBean> viewByStud(String studId) throws SQLException {
		
		List<ResultBean> resBean = new ArrayList<ResultBean>();
		resBean = getJdbcTemplate().query("SELECT  * FROM RESULT WHERE id = ? ORDER BY SCORE",new Object[]{studId},new int[]{Types.VARCHAR},new StudRowMapper());
		
		return resBean;
	}
}
