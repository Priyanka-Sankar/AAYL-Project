package com.project.result;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.connection.ConnectionManager;
import com.project.exam.ExamBean;
import com.project.exam.ExamDao;
import com.project.student.StudentDao;

public class ResultDao {

	public void insertResult(ResultBean resultBean) throws SQLException {
		ExamDao examDao = new ExamDao();
		ExamBean examBean = examDao.fetchExamDet(resultBean.getEid());
		int score = (examBean.getPosMark() * resultBean.getCorrectAns()) - (examBean.getNegMark() * resultBean.getWrongAns());
		resultBean.setScore(score);
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="INSERT INTO RESULT VALUES('"+resultBean.getSid()+"','"+resultBean.getEid()+"',"
							+resultBean.getCorrectAns()+","+resultBean.getWrongAns()+","+resultBean.getScore()+")";
			System.out.println(sql);
			if(st.executeUpdate(sql) > 0)
				System.out.println("Inserted");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
		}
	}

	public ResultBean viewResult(String id, String eid) throws SQLException {
		
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		ResultBean resultBean = new ResultBean(); ;
		try {
			 stmt = conn.createStatement();
			 String sql = "SELECT * FROM RESULT WHERE id = '"+id+"' AND eid = '"+eid+"'";
			ResultSet resultset = stmt.executeQuery(sql);	
			System.out.println(sql);
		
			while(resultset.next()) {
				resultBean.setEid(eid);
				resultBean.setSid(id);
				resultBean.setCorrectAns(resultset.getInt(3));
				resultBean.setWrongAns(resultset.getInt(4));
				resultBean.setScore(resultset.getInt(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally
		{
			ConnectionManager.close();
		}	
		
		return resultBean;
	}

	public void viewByExam(String examId) throws SQLException {
		
		StudentDao studDao = new StudentDao();
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try {
			 stmt = conn.createStatement();
			 String sql = "SELECT * FROM RESULT WHERE eid = '"+examId+"' ORDER BY SCORE DESC";
			 System.out.println(sql);
			ResultSet resultset = stmt.executeQuery(sql);
			if(resultset != null)
			{
			System.out.println("---------------------------------------------------------");
			System.out.println("Student Name\tCorrect Ans\tWrong Ans\tScore");
			while(resultset.next())
			{
				String sname = studDao.getStudName(resultset.getString(1));
				System.out.println(sname+"  "+resultset.getString(3)+"  "+resultset.getString(4)+"  "+resultset.getString(5));
			}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally
		{
			ConnectionManager.close();
		}
	}

	public void viewByStudent(String studName) throws SQLException {
		
		ExamDao examDao = new ExamDao();
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try {
			 stmt = conn.createStatement();
			ResultSet resultset = stmt.executeQuery("SELECT  Result.* FROM EXAM NATURAL JOIN RESULT NATURAL JOIN STUDENT WHERE sname = '"+studName+"' ORDER BY SCORE");
			if(resultset != null)
			{
			System.out.println("---------------------------------------------------------");
			System.out.println("Exam Name\tCorrect Ans\tWrong Ans\tScore");
			while(resultset.next())
			{
				
				System.out.println(resultset.getString(1)+"\t\t"+resultset.getString(2)+"\t\t"+resultset.getString(3)+"\t\t"+resultset.getString(4));
			}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally
		{
			ConnectionManager.close();
		}
	}
public List<ResultBean> viewByStud(String studId) throws SQLException {
		
		ExamDao examDao = new ExamDao();
		ArrayList<ResultBean> resBean = new ArrayList<ResultBean>();
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try {
			 stmt = conn.createStatement();
			 String sql="SELECT  * FROM RESULT WHERE id = '"+studId+"' ORDER BY SCORE";
			ResultSet resultset = stmt.executeQuery(sql);
			System.out.println(sql);
			if(resultset != null)
			{
			System.out.println("---------------------------------------------------------");
			System.out.println("Exam Name\tCorrect Ans\tWrong Ans\tScore");
			while(resultset.next())
			{
				resBean.add(new ResultBean(resultset.getString(1),resultset.getString(2),resultset.getInt(3),resultset.getInt(4),resultset.getInt(5)));
				System.out.println(resultset.getString(1)+"\t\t"+resultset.getString(2)+"\t\t"+resultset.getString(3)+"\t\t"+resultset.getString(4));
			}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally
		{
			ConnectionManager.close();
		}
		return resBean;
	}
public ArrayList<ResultBean> viewAllResultsByExam(String studName, String examId) throws SQLException {
		ArrayList<ResultBean> resultList = new ArrayList<ResultBean>();
		ExamDao examDao = new ExamDao();
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try {
			 stmt = conn.createStatement();
			 String sql="SELECT  R.id, eid, correctAns, wrongAns, score FROM STUDENT NATURAL JOIN RESULT R NATURAL JOIN EXAM WHERE eid='"+examId+"' AND R.id='"+studName+"'";
			ResultSet resultset = stmt.executeQuery(sql);
			System.out.println(sql);
			if(resultset != null)
			{
			//System.out.println("---------------------------------------------------------");
			//System.out.println("Exam Name\tCorrect Ans\tWrong Ans\tScore");
			while(resultset.next())
			{
				resultList.add(new ResultBean(resultset.getString(1), resultset.getString(2), resultset.getInt(3), resultset.getInt(4), resultset.getInt(5)));
				//System.out.println(resultset.getString(1)+"\t\t"+resultset.getString(2)+"\t\t"+resultset.getString(3)+"\t\t"+resultset.getString(4));
			}
			}
			return resultList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally
		{
			ConnectionManager.close();
		}
		return null;
	}

}
