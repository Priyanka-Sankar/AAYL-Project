package com.project.result;

public class ResultBean {
	private String sid;
	private String eid;
	private int correctAns;
	private int wrongAns;
	private int score;
	
	public ResultBean(String sid, String eid, int correctAns, int wrongAns, int score) {
		super();
		this.sid = sid;
		this.eid = eid;
		this.correctAns = correctAns;
		this.wrongAns = wrongAns;
		this.score = score;
	}
	public ResultBean() {
		// TODO Auto-generated constructor stub
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public int getCorrectAns() {
		return correctAns;
	}
	public void setCorrectAns(int correctAns) {
		this.correctAns = correctAns;
	}
	public int getWrongAns() {
		return wrongAns;
	}
	public void setWrongAns(int wrongAns) {
		this.wrongAns = wrongAns;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
}
