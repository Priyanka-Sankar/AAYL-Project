package com.project.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
	 static Connection con;
	   static String url;
	         
	   public static Connection getConnection()
	   {
	     
	      try
	      {
	    	  Class.forName("org.apache.derby.jdbc.ClientDriver");
	         try {
					con = DriverManager.getConnection("jdbc:derby://172.24.18.133:1527/Project;create=true","user","pwd");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	      }

	      catch(ClassNotFoundException e)
	      {
	         System.out.println(e);
	      }

	   return con;
	}
	   public static void close() throws SQLException
	   {
		   con.close();
	   }
}
