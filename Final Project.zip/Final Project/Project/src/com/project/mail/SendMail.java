package com.project.mail;

import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.project.result.ResultBean;
import com.project.staff.StaffDao;

public class SendMail {

	final static Logger logger = Logger.getLogger(SendMail.class);
	public String to_mail; 
	public SendMail(String loginId) throws SQLException {
		
		@SuppressWarnings("deprecation")
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\XBBNC93\\workspace2\\Project\\WebContent\\WEB-INF\\spring-servlet.xml"));
		DataSource obj = (DataSource) factory.getBean("ds");    
		StaffDao staffDao = new StaffDao(obj);
		to_mail = staffDao.getEmail(loginId);
		logger.info("Constructor called");
	}
	
    public void send(ResultBean rsb, String ename, String sname)  
    {
      
        //System.out.println(obj.getEmail_id() + obj.getPassword());

       

       // Sender's email ID needs to be mentioned
       String from = "priyanka.sankar@bnymellon.com";

       // Assuming you are sending email from localhost
       String host = "smtp.bnymellon.net";

       // Get system properties
       Properties properties = System.getProperties();

       // Setup mail server
       properties.setProperty("mail.smtp.host", host);

       // Get the default Session object.
       Session session = Session.getDefaultInstance(properties);

      try{
          // Create a default MimeMessage object.
          MimeMessage message = new MimeMessage(session);

          // Set From: header field of the header.
          message.setFrom(new InternetAddress(from));

          // Set To: header field of the header.
          message.addRecipient(Message.RecipientType.TO, new InternetAddress(to_mail));

          String report="";
          
            report+="Student Id : "+rsb.getSid()+"\n";
            report+="Student Name : "+sname+"\n";
           report+="Exam Id : "+rsb.getEid()+"\n";
           report +="Exam Name : "+sname+"\n";
          report+="no of correct ans : "+rsb.getCorrectAns()+"\n";
          report+="no of wrong ans : "+rsb.getWrongAns()+"\n";
          
          report+="score:"+rsb.getScore()+"\n";
          // Set Subject: header field
          message.setSubject("Report");

          // Now set the actual message
          message.setText(report);

          // Send message
          Transport.send(message);
          
      logger.info(report);
      }
      catch(Exception e)
      {
    	 logger.error(e.getMessage()); 
      }
 }     

}
