package com.project.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.project.result.ResultBean;

public class StudRowMapper implements RowMapper {

	public List<ResultBean> mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		List<ResultBean> resBean = new ArrayList<ResultBean>();
		while(rs.next())
		{
			System.out.println("Res id" + rs.getString(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getInt(3));
			System.out.println(rs.getInt(4));
			System.out.println(rs.getInt(5));
			resBean.add(new ResultBean(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getInt(5)));
		}
		System.out.println("Resultvean size :"+resBean.size());
		return resBean;
	}

}
