package com.project.angular;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.project.exam.ExamDao;
import com.project.result.ResultBean;
import com.project.result.ResultDao;
/**
 * Servlet implementation class ResultServlet
 */
@WebServlet("/ResultServlet")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig config;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void init(ServletConfig config)
	{
		this.config = config;
		System.out.println("Insideeeeeeeeeeeeeeee");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			ExamDao examDao = new ExamDao();
			
	        ResultDao res = new ResultDao();
	        List<ResultBean> resBean = res.viewByStud(request.getParameter("studId"));  
	        //String eName = examDao.fetchExamDet()
	        String json = new Gson().toJson(resBean);
	         
	         response.setContentType("application/json");
	         response.getWriter().write(json);
	         
	      }
	      catch (Exception e) {
	         e.printStackTrace();
	      }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
