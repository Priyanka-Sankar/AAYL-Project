package com.project.exam;

public class ExamBean {
	private String examId;
	private String examName;
	private int posMark;
	private int negMark;
	private int duration;
	
	public ExamBean(String examId, String examName, int posMark, int negMark, int duration) {
		super();
		this.examId = examId;
		this.examName = examName;
		this.posMark = posMark;
		this.negMark = negMark;
		this.duration = duration;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public ExamBean() {
		// TODO Auto-generated constructor stub
	}
	public String getExamId() {
		return examId;
	}
	public void setExamId(String examId) {
		this.examId = examId;
	}
	public String getExamName() {
		return examName;
	}
	public void setExamName(String examName) {
		this.examName = examName;
	}
	public int getPosMark() {
		return posMark;
	}
	public void setPosMark(int posMark) {
		this.posMark = posMark;
	}
	public int getNegMark() {
		return negMark;
	}
	public void setNegMark(int negMark) {
		this.negMark = negMark;
	}
	
}
