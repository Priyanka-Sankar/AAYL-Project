package com.project.exam;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.connection.ConnectionManager;
import com.project.question.QuestionDao;

public class ExamDao {
	public List<String> printExam() throws SQLException
	{
		List<String> exam = new ArrayList<String>();
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try
		{ 
			stmt = conn.createStatement();		 
			ResultSet resultset = stmt.executeQuery("SELECT eid,ename FROM exam");
			while(resultset.next())
			{
				exam.add(resultset.getString(1)+"\t"+resultset.getString(2));
			}
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return exam;
	}

	public void attendExam(String eid, String id) throws SQLException {
			QuestionDao quesDao = new QuestionDao();
			quesDao.fetchQuestion(eid, id);
	}
	
	public int getDuration(String eid) throws SQLException
	{
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try
		{ 
			stmt = conn.createStatement();		 
			ResultSet resultset = stmt.executeQuery("SELECT duration FROM EXAM WHERE eid = '"+eid+"'");
			if(resultset.next())
				return resultset.getInt(1);
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return -1;
	}
	public ExamBean fetchExamDet(String eid) throws SQLException {
		ExamBean exam = new ExamBean();
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try
		{ 
			stmt = conn.createStatement();		 
			ResultSet resultset = stmt.executeQuery("SELECT * FROM EXAM WHERE eid = '"+eid+"'");
			while(resultset.next())
			{
				exam.setExamId(eid);
				exam.setExamName(resultset.getString(2));
				exam.setPosMark(resultset.getInt(3));
				exam.setNegMark(resultset.getInt(4));
			}
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return exam;
	}

	public String fetchExamId(String ename) throws SQLException {
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		try
		{ 
			stmt = conn.createStatement();		 
			ResultSet resultset = stmt.executeQuery("SELECT eid FROM EXAM WHERE ename = '"+ename+"'");
			if(resultset.next())
				return resultset.getString(1);
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return null;
	}

	public Boolean addExam(ExamBean examBean) throws SQLException {
		
		String eid = examBean.getExamId();
		String ename = examBean.getExamName();
		int posMark = examBean.getPosMark();
		int negMark = examBean.getNegMark();
		int duration = examBean.getDuration();
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="INSERT INTO EXAM VALUES('"+eid+"','"+ename+"',"+posMark+","+negMark+","+duration+")";
		//	System.out.println(sql);
			if(st.executeUpdate(sql) > 0)
				return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
		}
		return false;
	}

	public Boolean deleteExam(String examId) throws SQLException {
		
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="DELETE FROM QUESTION WHERE eid='"+examId+"'";
			System.out.println(sql);
			st.executeUpdate(sql);
			sql = "DELETE FROM EXAM WHERE eid = '"+examId+"'";
			System.out.println(sql);
			if(st.executeUpdate(sql)>0)
				return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
		}
		return false;
	}
}
