package com.project.question;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.project.connection.ConnectionManager;
import com.project.result.ResultBean;
import com.project.result.ResultDao;

public class QuestionDao {
	
	ResultDao resultDao = new ResultDao(); 
	public ArrayList<QuestionBean> fetchQuestion(String eid, String id) throws SQLException {
		Scanner get = new Scanner(System.in);
		Connection conn = ConnectionManager.getConnection();
		Statement stmt = null;
		ArrayList<QuestionBean> qBeanList = new ArrayList<QuestionBean>();
		int correct = 0, wrong = 0;
		try
		{ 
			stmt = conn.createStatement();		 
			ResultSet resultset = stmt.executeQuery("SELECT * FROM QUESTION WHERE eid ='"+eid+"'");
			
			
			while(resultset.next())
			{
				qBeanList.add(new QuestionBean(resultset.getInt(2), resultset.getString(3), resultset.getString(4), resultset.getString(5), resultset.getString(6), resultset.getString(7), resultset.getInt(8)));
			}
				/*System.out.println("----------Question No "+resultset.getInt(2)+"-------");
				System.out.println(resultset.getString(3));
				System.out.println("1) "+resultset.getString(4));
				System.out.println("2) "+resultset.getString(5));
				System.out.println("3) "+resultset.getString(6));
				System.out.println("4) "+resultset.getString(7));
				System.out.println("Enter your correct option :");
				int ch = Integer.parseInt(get.nextLine());
				if(ch == resultset.getInt(8))
					correct++;
				else
					wrong++;
			}
			resultDao.insertResult(new ResultBean(id, eid, correct, wrong, 0));			
			System.out.println("---------Thank You.. You have completed exam--------");*/
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally
			{
				ConnectionManager.close();
			}	
		return qBeanList;
	}

	public Boolean addQuestion(String examId, QuestionBean qBean) throws SQLException {
		
		int qid = qBean.getQid();
		String desc = qBean.getDesc();
		String optA = qBean.getOptA();
		String optB = qBean.getOptB();
		String optC = qBean.getOptC();
		String optD = qBean.getOptD();
		int correctAns = qBean.getCorrectAns();
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="INSERT INTO QUESTION VALUES('"+examId+"',"+qid+",'"+desc+"','"+optA+"','"+optB+"','"+optC+"','"+optD+"',"+correctAns+")";
			System.out.println(sql);
			if(st.executeUpdate(sql) > 0)
				return true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
		}
		return false;		
	}

	public void deleteQuestion(String examId, int quesId) throws SQLException {
		
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="DELETE FROM QUESTION WHERE eid='"+examId+"' AND qid = "+quesId+"";
			st.executeUpdate(sql);
			System.out.println("Deleted");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
		}
	}

	public int getCount(String examId) throws SQLException {
		
		Connection con=ConnectionManager.getConnection();
		if(con != null)
		{
			try{
			Statement st=con.createStatement();
			String sql="SELECT COUNT(*) FROM QUESTION WHERE eid='"+examId+"'";
			ResultSet resultset = st.executeQuery(sql);
			if(resultset.next())
			{
				return resultset.getInt(1);
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				ConnectionManager.close();
			}
		}
		return (Integer) null;
	}

}
