function isStudEmpty(){
	var loginId = document.studLogin.stid.value;
	var pwd = document.studLogin.pwd.value;
	if(loginId == null || pwd == null || loginId == "" || pwd == ""){
		alert("Fields should not be null");
		return false;
	}
	if(pwd.length < 6){
		alert("Password should have minimum of 6 letters");
		return false;
	}
	return true;	
}
function isStaffEmpty(){
	var loginId = document.staffLogin.stid.value;
	var pwd = document.staffLogin.pwd.value;
	if(loginId == null || pwd == null || loginId == "" || pwd == ""){
		alert("Fields should not be null");
		return false;
	}
	if(pwd.length < 6){
		alert("Password should have minimum of 6 letters");
		return false;
	}
	return true;
}
function passValid(){
	var pwd = document.chpwd.pwd.value;
	var cpwd = document.chpwd.cpwd.value;
	if(pwd.length < 6){
		alert("Password should have minimum of 6 letters");
		return false;
	}
	if(pwd != cpwd){
		alert("Password and Confirm password should be equal");
		return false;
	}
	return true;
}
function staffValid(){
	var loginId = document.staffSignup.stid.value;
	var name = document.staffSignup.stname.value;
	var pwd = document.staffSignup.pwd.value;
	var email = document.staffSignup.email.value;
	var cpwd = document.staffSignup.cpwd.value;
	if(loginId == null || pwd == null || loginId == "" || pwd == "" || name == null || name == "" || cpwd == null || cpwd == "" || email == null || email == ""){
		alert("Fields should not be null");
		return false;
	}
	if(pwd.length < 6){
		alert("Password should have minimum of 6 letters");
		return false;
	}
	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
	  {
		alert("You have entered an invalid email address!");
	    return (false);
	  }
	if(pwd != cpwd){
		alert("Password and Confirm password should be equal");
		return false;
	}
	return true;
}
function studentValid(){
	var loginId = document.addStudent.stid.value;
	var name = document.addStudent.stname.value;
	var dept = document.addStudent.dept.value;
	var pwd = document.addStudent.pwd.value;
	var cpwd = document.addStudent.cpwd.value;
	if(loginId == null || pwd == null || loginId == "" || pwd == "" || name == null || name == "" || cpwd == null || cpwd == "" || dept == null || dept == ""){
		alert("Fields should not be null");
		return false;
	}
	if(pwd.length < 6){
		alert("Password should have minimum of 6 letters");
		return false;
	}
	
	if(pwd != cpwd){
		alert("Password and Confirm password should be equal");
		return false;
	}
	return true;
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function logout(){
	alert("You have successfully logout..");
	//window.close();
}
function dispQues(){
	alert("Now you can add questions..!!");
}
function setValue(val){
	document.getElementById("testN").value = val;
}
$(document).ready(function () {
    var counter = 1;

    $("#addrow").on("click", function () {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counter + '" required/></td> ';
        cols += '<td><input type="text" class="form-control" name="optA' + counter + '" required /></td>';
        cols += '<td><input type="text" class="form-control" name="optB' + counter + '" required /></td>';
        cols += '<td><input type="text" class="form-control" name="optC' + counter + '" required/></td>';
        cols += '<td><input type="text" class="form-control" name="optD' + counter + '" required/></td>';
        cols += '<td class="col-sm-1 selectContainer"><select class="form-control" name="ques' + counter + '">'+
        		'<option value="1">A</option>'+
        		'<option value="2">B</option>'+ 
        		'<option value="3">C</option>'+ 
        		'<option value="4">D</option>'+ 
        		'</select></td>';
        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
        document.addStudent.count.value = ""+counter;
    });

    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();       
    });


});


